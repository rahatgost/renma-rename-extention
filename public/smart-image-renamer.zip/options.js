const DEFAULT_TEMPLATE = "{prefix}_{date}_{time}_{counter}.{ext}";
const TOKENS = ["prefix", "domain", "host", "date", "time", "timestamp", "counter", "originalName", "ext", "width", "height", "dimensions"];

const $ = (id) => document.getElementById(id);

async function get(keys) {
  return chrome.storage.local.get(keys);
}
async function set(obj) {
  return chrome.storage.local.set(obj);
}

/* ---------- Toggles ---------- */
function bindSwitch(id, key, defVal = false) {
  const el = $(id);
  chrome.storage.local.get(key).then((s) => {
    const v = key in s ? s[key] : defVal;
    el.classList.toggle("on", !!v);
  });
  el.addEventListener("click", async () => {
    const s = await chrome.storage.local.get(key);
    const cur = key in s ? s[key] : defVal;
    const next = !cur;
    await chrome.storage.local.set({ [key]: next });
    el.classList.toggle("on", next);
  });
}

/* ---------- Template ---------- */
const templateEl = $("template");
const previewEl = $("preview");
const tokenListEl = $("tokenList");

function renderTokens() {
  tokenListEl.innerHTML =
    "Tokens: " +
    TOKENS.map((t) => `<code data-tok="{${t}}">{${t}}</code>`).join(" ");
  tokenListEl.querySelectorAll("code").forEach((c) =>
    c.addEventListener("click", () => {
      const t = c.dataset.tok;
      const start = templateEl.selectionStart ?? templateEl.value.length;
      const end = templateEl.selectionEnd ?? templateEl.value.length;
      templateEl.value =
        templateEl.value.slice(0, start) + t + templateEl.value.slice(end);
      templateEl.focus();
      templateEl.selectionStart = templateEl.selectionEnd = start + t.length;
      saveTemplate();
    })
  );
}

function pad(n, w = 2) { return String(n).padStart(w, "0"); }

function previewFor(template) {
  const now = new Date();
  const tokens = {
    prefix: "Unsplash",
    domain: "unsplash",
    host: "unsplash.com",
    date: `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`,
    time: `${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`,
    timestamp: now.getTime(),
    counter: "0042",
    originalName: "photo-hero",
    ext: "jpg",
    width: "1920",
    height: "1080",
    dimensions: "1920x1080",
  };
  return (template || DEFAULT_TEMPLATE).replace(/\{(\w+)\}/g, (_, k) =>
    tokens[k] === undefined ? "" : String(tokens[k])
  );
}

async function loadTemplate() {
  const { template = DEFAULT_TEMPLATE } = await get("template");
  templateEl.value = template;
  previewEl.textContent = previewFor(template);
}

async function saveTemplate() {
  const v = templateEl.value.trim() || DEFAULT_TEMPLATE;
  previewEl.textContent = previewFor(v);
  await set({ template: v });
}
templateEl.addEventListener("input", saveTemplate);

/* ---------- Mappings ---------- */
const mapListEl = $("mapList");
const mStatus = $("m-status");

function flash(el, msg) {
  el.textContent = msg;
  setTimeout(() => (el.textContent = ""), 1500);
}

async function renderMappings() {
  const { customMappings = [] } = await get("customMappings");
  mapListEl.innerHTML = "";
  if (customMappings.length === 0) {
    mapListEl.innerHTML = `<tr><td colspan="4" class="empty-cell">No custom rules yet — add your first below.</td></tr>`;
    return;
  }
  customMappings.forEach((m, i) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td class="mono"></td>
      <td class="prefix-cell"></td>
      <td class="mono"></td>
      <td style="text-align:right"><button class="del" data-i="${i}">Remove</button></td>`;
    tr.children[0].textContent = m.domain;
    tr.children[1].textContent = m.prefix;
    tr.children[2].textContent = m.folder || "—";
    mapListEl.appendChild(tr);
  });
  mapListEl.querySelectorAll(".del").forEach((btn) =>
    btn.addEventListener("click", async (e) => {
      const i = Number(e.target.dataset.i);
      const { customMappings = [] } = await get("customMappings");
      customMappings.splice(i, 1);
      await set({ customMappings });
      flash(mStatus, "Removed");
      renderMappings();
    })
  );
}

$("m-add").addEventListener("click", async () => {
  const domain = $("m-domain").value.trim().toLowerCase();
  const prefix = $("m-prefix").value.trim();
  const folder = $("m-folder").value.trim();
  if (!domain || !prefix) return flash(mStatus, "Domain and prefix are required");
  const { customMappings = [] } = await get("customMappings");
  customMappings.push({ domain, prefix, folder: folder || undefined });
  await set({ customMappings });
  $("m-domain").value = ""; $("m-prefix").value = ""; $("m-folder").value = "";
  flash(mStatus, "Saved");
  renderMappings();
});

/* ---------- Site scope ---------- */
const modeSeg = $("modeSeg");
const siteChipsEl = $("siteChips");

async function renderMode() {
  const { siteMode = "all" } = await get("siteMode");
  modeSeg.querySelectorAll("button").forEach((b) =>
    b.classList.toggle("active", b.dataset.mode === siteMode)
  );
}
modeSeg.querySelectorAll("button").forEach((b) =>
  b.addEventListener("click", async () => {
    await set({ siteMode: b.dataset.mode });
    renderMode();
  })
);

async function renderSites() {
  const { siteList = [] } = await get("siteList");
  siteChipsEl.innerHTML = "";
  if (siteList.length === 0) {
    siteChipsEl.innerHTML = `<span style="font-size:12px;color:var(--muted-soft)">No sites yet.</span>`;
    return;
  }
  siteList.forEach((d, i) => {
    const chip = document.createElement("span");
    chip.className = "chip";
    chip.innerHTML = `<span></span><button data-i="${i}" aria-label="Remove">×</button>`;
    chip.children[0].textContent = d;
    siteChipsEl.appendChild(chip);
  });
  siteChipsEl.querySelectorAll("button").forEach((btn) =>
    btn.addEventListener("click", async (e) => {
      const i = Number(e.currentTarget.dataset.i);
      const { siteList = [] } = await get("siteList");
      siteList.splice(i, 1);
      await set({ siteList });
      renderSites();
    })
  );
}

$("s-add").addEventListener("click", async () => {
  const domain = $("s-domain").value.trim().toLowerCase();
  if (!domain) return;
  const { siteList = [] } = await get("siteList");
  if (!siteList.includes(domain)) siteList.push(domain);
  await set({ siteList });
  $("s-domain").value = "";
  renderSites();
});

/* ---------- Duplicate mode ---------- */
const dupSeg = $("dupSeg");
async function renderDupMode() {
  const { duplicateMode = "tag" } = await get("duplicateMode");
  dupSeg.querySelectorAll("button").forEach((b) =>
    b.classList.toggle("active", b.dataset.mode === duplicateMode)
  );
}
dupSeg.querySelectorAll("button").forEach((b) =>
  b.addEventListener("click", async () => {
    await set({ duplicateMode: b.dataset.mode });
    renderDupMode();
  })
);

/* ---------- Counter ---------- */
async function renderCounter() {
  const { counter = 0 } = await get("counter");
  $("counterVal").textContent = String(counter).padStart(4, "0");
}
$("resetCounter").addEventListener("click", async () => {
  await set({ counter: 0 });
  renderCounter();
});

/* ---------- Stats ---------- */
async function renderStats() {
  const { stats = { total: 0, byDomain: {}, byDay: {} } } = await get("stats");
  const today = new Date().toISOString().slice(0, 10);
  $("stat-total").textContent = stats.total || 0;
  $("stat-today").textContent = stats.byDay?.[today] || 0;
  $("stat-sources").textContent = Object.keys(stats.byDomain || {}).length;

  const entries = Object.entries(stats.byDomain || {}).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const max = entries[0]?.[1] || 1;
  const top = $("topDomains");
  top.innerHTML = "";
  if (entries.length === 0) {
    top.innerHTML = `<div style="font-family:'Instrument Serif',serif;font-size:15px;color:var(--muted-soft);text-align:center;padding:20px">No downloads tracked yet.</div>`;
    return;
  }
  entries.forEach(([domain, count]) => {
    const pct = (count / max) * 100;
    const row = document.createElement("div");
    row.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:baseline;margin-bottom:4px">
        <span style="font-family:'JetBrains Mono',monospace;font-size:12.5px;color:var(--body)"></span>
        <span style="font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--coral);font-weight:500"></span>
      </div>
      <div style="height:6px;background:var(--surface-soft);border-radius:999px;overflow:hidden">
        <div style="height:100%;width:${pct}%;background:var(--coral);border-radius:999px"></div>
      </div>`;
    row.children[0].children[0].textContent = domain;
    row.children[0].children[1].textContent = count;
    top.appendChild(row);
  });
}
$("resetStats").addEventListener("click", async () => {
  await set({ stats: { total: 0, byDomain: {}, byDay: {} } });
  renderStats();
});

/* ---------- Backup ---------- */
const bStatus = $("b-status");
const BACKUP_KEYS = [
  "enabled", "template", "dateFolders", "dateFolderFormat",
  "siteMode", "siteList", "customMappings", "filetypes",
  "onlyImages", "notifications", "duplicateMode", "fetchDimensions",
  "filenameCase", "maxNameLength", "aiPrefix",
];
$("exportSettings").addEventListener("click", async () => {
  const data = await get(BACKUP_KEYS);
  const blob = new Blob([JSON.stringify({ __renma: 1, version: 1, data }, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `renma-settings-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  flash(bStatus, "Exported");
});
$("importFile").addEventListener("change", async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;
  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    const data = parsed.data || parsed;
    const clean = {};
    BACKUP_KEYS.forEach((k) => { if (k in data) clean[k] = data[k]; });
    await set(clean);
    flash(bStatus, "Imported — reloading");
    setTimeout(() => location.reload(), 700);
  } catch (err) {
    bStatus.style.color = "#c64545";
    bStatus.textContent = "Invalid file";
    setTimeout(() => { bStatus.textContent = ""; bStatus.style.color = ""; }, 2000);
  }
});

/* ---------- Bulk rename ---------- */
const bulkListEl = $("bulk-list");
const bulkEmptyEl = $("bulk-empty");
const bulkToolbarEl = $("bulk-toolbar");
const bulkStatusEl = $("bulk-status");
const bulkAllEl = $("bulk-all");
const bulkCountEl = $("bulk-count");
const bulkDeleteEl = $("bulk-delete");

let bulkItems = [];

const IMG_EXT_RE = /\.(png|jpe?g|gif|webp|avif|bmp|svg|tiff?|ico|heic)$/i;

function basename(p) {
  if (!p) return "";
  const parts = String(p).replace(/\\/g, "/").split("/");
  return parts[parts.length - 1] || String(p);
}

function previewName(payload) {
  return new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: "preview-name", payload }, (res) => {
        if (chrome.runtime.lastError) return resolve({ error: chrome.runtime.lastError.message });
        resolve(res || {});
      });
    } catch (e) {
      resolve({ error: String(e?.message || e) });
    }
  });
}

function updateBulkCount() {
  const n = bulkListEl.querySelectorAll('input[data-bulk]:checked').length;
  bulkCountEl.textContent = `${n} selected`;
}

async function renderBulkList() {
  bulkListEl.innerHTML = "";
  if (bulkItems.length === 0) {
    bulkEmptyEl.style.display = "block";
    bulkToolbarEl.style.display = "none";
    return;
  }
  bulkEmptyEl.style.display = "none";
  bulkToolbarEl.style.display = "flex";

  for (let i = 0; i < bulkItems.length; i++) {
    const it = bulkItems[i];
    const original = basename(it.filename);
    const looksMessy = /^image( \(\d+\))?\.[a-z]+$/i.test(original)
      || /^unnamed/i.test(original)
      || /^download/i.test(original);
    const row = document.createElement("div");
    row.style.cssText =
      "display:grid;grid-template-columns:auto 1fr auto;gap:12px;align-items:center;padding:12px 14px;background:#fff;border:1px solid var(--hairline);border-radius:12px";
    row.innerHTML = `
      <input type="checkbox" data-bulk data-i="${i}" style="width:auto;accent-color:var(--coral);margin-top:2px" ${looksMessy ? "checked" : ""} />
      <div style="min-width:0">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
          <span class="orig-name" style="font-family:'JetBrains Mono',monospace;font-size:12.5px;color:var(--body);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:100%"></span>
          ${looksMessy ? '<span style="font-family:\'JetBrains Mono\',monospace;font-size:9.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--coral);background:var(--coral-soft);padding:2px 7px;border-radius:999px">messy</span>' : ""}
        </div>
        <div style="display:flex;align-items:center;gap:6px;font-family:'JetBrains Mono',monospace;font-size:12px;color:var(--muted-soft)">
          <span>→</span>
          <span class="new-name" style="color:var(--coral);overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></span>
        </div>
        <div class="host" style="font-family:'JetBrains Mono',monospace;font-size:10.5px;color:var(--muted-soft);margin-top:3px;letter-spacing:.05em"></div>
      </div>
      <a class="open-src" href="${it.url || '#'}" target="_blank" rel="noopener" title="Open source in a new tab" style="font-size:11.5px;color:var(--muted);text-decoration:none;padding:6px 10px;border:1px solid var(--hairline);border-radius:999px">Source ↗</a>
    `;
    row.querySelector(".orig-name").textContent = original || "(no filename)";
    const newEl = row.querySelector(".new-name");
    const hostEl = row.querySelector(".host");
    hostEl.textContent = "resolving…";
    newEl.textContent = "…";
    bulkListEl.appendChild(row);

    previewName({ url: it.url, filename: original, mime: it.mime }).then((res) => {
      if (res?.skipped) {
        newEl.textContent = `(skipped: ${res.skipped})`;
        newEl.style.color = "var(--muted-soft)";
        const cb = row.querySelector('input[data-bulk]');
        cb.checked = false;
        cb.disabled = true;
        row.style.opacity = "0.6";
      } else if (res?.finalPath) {
        newEl.textContent = res.finalPath;
        it._previewed = res.finalPath;
      } else {
        newEl.textContent = res?.error || "(preview failed)";
        newEl.style.color = "var(--muted-soft)";
      }
      hostEl.textContent = res?.hostname || "(no source)";
      updateBulkCount();
    });
  }

  bulkListEl.querySelectorAll('input[data-bulk]').forEach((cb) => {
    cb.addEventListener("change", updateBulkCount);
  });
  updateBulkCount();
}

$("bulk-scan").addEventListener("click", async () => {
  bulkStatusEl.style.color = "";
  bulkStatusEl.textContent = "";
  try {
    const items = await chrome.downloads.search({
      limit: 100,
      orderBy: ["-startTime"],
      exists: true,
    });
    bulkItems = items
      .filter((it) => it && it.url && (
        (it.mime && it.mime.startsWith("image/")) || IMG_EXT_RE.test(it.filename || "")
      ))
      .slice(0, 100);
    await renderBulkList();
    flash(bulkStatusEl, `Loaded ${bulkItems.length} image download${bulkItems.length === 1 ? "" : "s"}`);
  } catch (e) {
    bulkStatusEl.style.color = "#c64545";
    bulkStatusEl.textContent = "Scan failed: " + (e?.message || e);
  }
});

bulkAllEl.addEventListener("change", () => {
  bulkListEl.querySelectorAll('input[data-bulk]:not(:disabled)').forEach((cb) => {
    cb.checked = bulkAllEl.checked;
  });
  updateBulkCount();
});

$("bulk-run").addEventListener("click", async () => {
  const boxes = Array.from(bulkListEl.querySelectorAll('input[data-bulk]:checked'));
  if (boxes.length === 0) {
    bulkStatusEl.style.color = "#c64545";
    bulkStatusEl.textContent = "Nothing selected.";
    setTimeout(() => { bulkStatusEl.textContent = ""; bulkStatusEl.style.color = ""; }, 1800);
    return;
  }
  const deleteOriginals = bulkDeleteEl.checked;
  let ok = 0;
  let fail = 0;
  bulkStatusEl.style.color = "";
  bulkStatusEl.textContent = `Working through ${boxes.length}…`;

  for (const cb of boxes) {
    const i = Number(cb.dataset.i);
    const src = bulkItems[i];
    if (!src?.url) { fail++; continue; }
    try {
      // Bulk re-download must not be treated as a duplicate by background.js
      const { seenUrls = [] } = await chrome.storage.local.get("seenUrls");
      if (seenUrls.includes(src.url)) {
        await chrome.storage.local.set({
          seenUrls: seenUrls.filter((u) => u !== src.url),
        });
      }
      await new Promise((resolve, reject) => {
        chrome.downloads.download({ url: src.url, conflictAction: "uniquify" }, (id) => {
          if (chrome.runtime.lastError || !id) {
            return reject(new Error(chrome.runtime.lastError?.message || "download failed"));
          }
          resolve(id);
        });
      });
      if (deleteOriginals && src.id) {
        try { await chrome.downloads.removeFile(src.id); } catch {}
        try { await chrome.downloads.erase({ id: src.id }); } catch {}
      }
      ok++;
      cb.closest("div[style*='grid']")?.remove();
    } catch {
      fail++;
    }
    bulkStatusEl.textContent = `Renamed ${ok} · Failed ${fail}`;
    await new Promise((r) => setTimeout(r, 120));
  }

  bulkStatusEl.textContent = fail === 0
    ? `Re-downloaded ${ok} file${ok === 1 ? "" : "s"} with renma naming.`
    : `Done — ${ok} succeeded, ${fail} failed.`;
  updateBulkCount();
});

/* ---------- Init ---------- */
bindSwitch("sw-enabled", "enabled", true);
bindSwitch("sw-onlyImages", "onlyImages", true);
bindSwitch("sw-dateFolders", "dateFolders", false);
bindSwitch("sw-notifications", "notifications", false);
bindSwitch("sw-fetchDimensions", "fetchDimensions", true);
renderTokens();
loadTemplate();
renderMappings();
renderMode();
renderSites();
renderDupMode();
renderCounter();
renderStats();
